/*!
 * SAP UI development toolkit for HTML5 (SAPUI5)
 * 
 * (c) Copyright 2009-2014 SAP AG. All rights reserved
 */
jQuery.sap.declare("sap.m.FacetFilterListRenderer");jQuery.sap.require("sap.ui.core.Renderer");jQuery.sap.require("sap.m.ListRenderer");jQuery.sap.declare("sap.m.FacetFilterListRenderer");sap.m.FacetFilterListRenderer=sap.ui.core.Renderer.extend(sap.m.ListRenderer);
