/*!
 * SAP UI development toolkit for HTML5 (SAPUI5)
 * 
 * (c) Copyright 2009-2014 SAP AG. All rights reserved
 */
sap.ui.define(['./library','./LayoutData'],function(){"use strict";sap.ui.core.LayoutData.extend("sap.ui.core.VariantLayoutData",{metadata:{library:"sap.ui.core",aggregations:{"multipleLayoutData":{type:"sap.ui.core.LayoutData",multiple:true,singularName:"multipleLayoutData"}}}});return sap.ui.core.VariantLayoutData},true);
