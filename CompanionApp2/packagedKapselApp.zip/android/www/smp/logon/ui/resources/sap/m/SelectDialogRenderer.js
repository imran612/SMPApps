/*!
 * SAP UI development toolkit for HTML5 (SAPUI5)
 * 
 * (c) Copyright 2009-2014 SAP AG. All rights reserved
 */
jQuery.sap.declare("sap.m.SelectDialogRenderer");sap.m.SelectDialogRenderer={};
sap.m.SelectDialogRenderer.render=function(r,c){};
