/*!
 * SAP UI development toolkit for HTML5 (SAPUI5)
 * 
 * (c) Copyright 2009-2014 SAP AG. All rights reserved
 */
sap.ui.define(['./library','./Item'],function(){"use strict";sap.ui.core.Item.extend("sap.ui.core.SeparatorItem",{metadata:{library:"sap.ui.core"}});return sap.ui.core.SeparatorItem},true);
